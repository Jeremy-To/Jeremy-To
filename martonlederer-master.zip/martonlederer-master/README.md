<h1 align="center">
  <img src="https://raw.githubusercontent.com/martonlederer/martonlederer/master/name.svg" alt="Marton Lederer" />
</h1>

## Hey! 👋
I'm Marton, a 18 years old web developer from Hungary.

- 🧭 Founder at [@th8ta](https://github.com/th8ta) and [@useverto](https://github.com/useverto)

- 👥 Core team member at [@nestdotland](https://github.com/nestdotland)

## Skills
- 👨‍💻 TypeScript, JavaScript, PHP, C#
- ⚙️ React, Svelte, Vue
- 👁️ SASS, CSS, Stylus
- 💽 MySQL, SQL, Mongo

## Contact
- [marton.lederer.hu](https://marton.lederer.hu)
- [@martonlederer](https://twitter.com/martonlederer) on Twitter
- [@martonlederer](https://twitter.com/instagram) on Instagram
- [Marton#6513](./) on Discord
